

from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import cv2
import os
# views.py



def upload_image(request):
    if request.method == 'POST' and request.FILES['image']:
        uploaded_image = request.FILES['image']
        fs = FileSystemStorage()
        file_name = fs.save(uploaded_image.name, uploaded_image)
        file_path = os.path.join(settings.MEDIA_ROOT, file_name)
        
        # Load and process the image using OpenCV
        image = cv2.imread(file_path)
        if image is None:
            return render(request, 'upload_photo.html', {
                'error_message': 'Error loading the image',
            })
        
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        inverted_image = cv2.bitwise_not(gray_image)
        blurred_image = cv2.GaussianBlur(inverted_image, (21, 21), 0)
        inverted_blurred_image = cv2.bitwise_not(blurred_image)
        sketch = cv2.divide(gray_image, inverted_blurred_image, scale=256.0)

        # Save the sketch as a new file
        sketch_file_name = f'sketch_{file_name}'
        sketch_file_path = os.path.join(settings.MEDIA_ROOT, sketch_file_name)
        cv2.imwrite(sketch_file_path, sketch)

        # Check if the files were saved successfully
        if not os.path.exists(file_path) or not os.path.exists(sketch_file_path):
            return render(request, 'upload_photo.html', {
                'error_message': 'Error saving the images',
            })

        return render(request, 'upload_photo.html', {
            'original_image_url': fs.url(file_name),
            'sketch_image_url': fs.url(sketch_file_name),
        })
    
    return render(request, 'upload_photo.html')

